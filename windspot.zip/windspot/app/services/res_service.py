"""
Service d'accès à la base RES (Recensement des Équipements Sportifs).
Stratégie : cache JSON local → fallback API data.gouv.fr
"""
import json
import math
import httpx
import logging
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

DATA_DIR = Path(__file__).resolve().parent.parent.parent / "data"
CACHE_FILE = DATA_DIR / "res_cache.json"

# Codes activités RES pour sports nautiques à voile
NAUTICAL_ACTIVITY_CODES = {
    "voile": ["413", "414", "415"],          # Voile légère, croisière, dériveur
    "planche_a_voile": ["430", "431"],        # Planche à voile / windsurf
    "kitesurf": ["432", "433"],              # Kitesurf / cerf-volant tracteur
}

# Types d'équipements nautiques dans la base RES
NAUTICAL_EQUIPMENT_TYPES = [
    "Plan d'eau calme",
    "Plan d'eau agité",
    "Base nautique",
    "Port de plaisance",
    "Centre nautique",
    "École de voile",
    "Club nautique",
    "Espace nautique",
]

# URL de l'API data.gouv.fr pour la base RES
RES_API_BASE = "https://equipements.sports.gouv.fr/api/explore/v2.1/catalog/datasets/res-01/records"


def haversine_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Calcule la distance en km entre deux points GPS (formule de Haversine)."""
    R = 6371.0
    phi1, phi2 = math.radians(lat1), math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlam = math.radians(lon2 - lon1)
    a = math.sin(dphi / 2) ** 2 + math.cos(phi1) * math.cos(phi2) * math.sin(dlam / 2) ** 2
    return R * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))


def load_cache() -> list[dict]:
    """Charge le cache local JSON s'il existe."""
    if CACHE_FILE.exists():
        try:
            with open(CACHE_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
            logger.info(f"Cache RES chargé : {len(data)} équipements")
            return data
        except Exception as e:
            logger.warning(f"Erreur lecture cache : {e}")
    return []


def save_cache(data: list[dict]) -> None:
    """Sauvegarde les données dans le cache local."""
    DATA_DIR.mkdir(exist_ok=True)
    with open(CACHE_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    logger.info(f"Cache RES sauvegardé : {len(data)} équipements")


async def fetch_from_api(lat: float, lon: float, radius_km: float) -> list[dict]:
    """
    Interroge l'API data.gouv.fr pour récupérer les équipements nautiques
    autour du point donné.
    """
    results = []
    offset = 0
    limit = 100

    # Approximation degré → km pour le filtre géographique
    lat_delta = radius_km / 111.0
    lon_delta = radius_km / (111.0 * math.cos(math.radians(lat)))

    where_clause = (
        f"coordgps_x >= {lat - lat_delta} AND coordgps_x <= {lat + lat_delta} "
        f"AND coordgps_y >= {lon - lon_delta} AND coordgps_y <= {lon + lon_delta}"
    )

    async with httpx.AsyncClient(timeout=15.0) as client:
        while True:
            params = {
                "where": where_clause,
                "limit": limit,
                "offset": offset,
                "select": "numinstallation,nominstallation,adresse,codepostal,commune,"
                          "departement,coordgps_x,coordgps_y,typequipement,activites",
            }
            try:
                resp = await client.get(RES_API_BASE, params=params)
                resp.raise_for_status()
                batch = resp.json().get("results", [])
                if not batch:
                    break
                results.extend(batch)
                offset += limit
                if len(batch) < limit:
                    break
            except httpx.HTTPError as e:
                logger.error(f"Erreur API RES : {e}")
                break

    logger.info(f"API RES : {len(results)} équipements récupérés")
    return results


def normalize_record(raw: dict) -> dict:
    """Normalise un enregistrement RES brut en format interne unifié."""
    lat = raw.get("coordgps_x") or raw.get("latitude")
    lon = raw.get("coordgps_y") or raw.get("longitude")

    try:
        lat = float(lat) if lat else None
        lon = float(lon) if lon else None
    except (ValueError, TypeError):
        lat, lon = None, None

    return {
        "id": str(raw.get("numinstallation", "")),
        "name": raw.get("nominstallation", "Équipement inconnu"),
        "type_installation": raw.get("typequipement", "Non précisé"),
        "address": raw.get("adresse", ""),
        "postal_code": str(raw.get("codepostal", "")),
        "city": raw.get("commune", ""),
        "department": raw.get("departement", ""),
        "latitude": lat,
        "longitude": lon,
        "activites": raw.get("activites", []),
    }


def is_nautical(record: dict) -> bool:
    """Filtre les équipements liés aux sports nautiques à voile."""
    type_inst = record.get("type_installation", "").lower()
    name = record.get("name", "").lower()

    nautical_keywords = [
        "nautique", "voile", "planche", "kite", "port", "mer", "lac",
        "plan d'eau", "base nautique", "centre nautique"
    ]
    return any(kw in type_inst or kw in name for kw in nautical_keywords)


async def get_spots_near(
    lat: float,
    lon: float,
    radius_km: float,
    sport: Optional[str] = None,
) -> list[dict]:
    """
    Point d'entrée principal : retourne les spots nautiques dans le rayon.
    Utilise le cache local en priorité, puis l'API en fallback.
    """
    cached = load_cache()

    if cached:
        logger.info("Utilisation du cache RES local")
        raw_spots = cached
    else:
        logger.info("Cache absent → appel API data.gouv.fr")
        raw_records = await fetch_from_api(lat, lon, radius_km * 2)
        raw_spots = [normalize_record(r) for r in raw_records]
        # On sauvegarde uniquement les équipements nautiques pour alléger le cache
        nautical_spots = [s for s in raw_spots if is_nautical(s)]
        save_cache(nautical_spots)
        raw_spots = nautical_spots

    # Filtrage par distance et validité GPS
    spots_in_radius = []
    for spot in raw_spots:
        if not spot.get("latitude") or not spot.get("longitude"):
            continue
        dist = haversine_km(lat, lon, spot["latitude"], spot["longitude"])
        if dist <= radius_km:
            spot["distance_km"] = round(dist, 2)
            spots_in_radius.append(spot)

    # Tri par distance croissante
    spots_in_radius.sort(key=lambda s: s["distance_km"])
    logger.info(f"{len(spots_in_radius)} spots trouvés dans un rayon de {radius_km} km")
    return spots_in_radius
