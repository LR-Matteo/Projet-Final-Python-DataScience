# WindSpot - Application FastAPI
